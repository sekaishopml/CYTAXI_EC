"use client";
import { useEffect, useRef, useState } from "react";

interface MapPreviewProps {
  onClick: () => void;
  shape?: "rounded" | "p-top";
}

const GUAYAQUIL = { lat: -2.170997, lng: -79.922359 };

export function MapPreview({ onClick, shape = "rounded" }: MapPreviewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const markerRef = useRef<google.maps.Marker | null>(null);
  const [center, setCenter] = useState(GUAYAQUIL);
  const [ready, setReady] = useState(false);
  const [live, setLive] = useState(false);
  const [hover, setHover] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!navigator.geolocation) { setReady(true); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => { setCenter({ lat: pos.coords.latitude, lng: pos.coords.longitude }); setReady(true); },
      () => { setReady(true); },
      { timeout: 5000, enableHighAccuracy: false },
    );
  }, []);

  useEffect(() => {
    if (!ready || !containerRef.current || mapRef.current) return;

    const tryInit = () => {
      if (!window.google?.maps || !containerRef.current) return false;
      const map = new google.maps.Map(containerRef.current, {
        center,
        zoom: 15,
        disableDefaultUI: true,
        zoomControl: false,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
        gestureHandling: "none",
        keyboardShortcuts: false,
        styles: [
          { featureType: "poi", stylers: [{ visibility: "off" }] },
          { featureType: "transit", stylers: [{ visibility: "off" }] },
        ],
      });

      markerRef.current = new google.maps.Marker({
        position: center,
        map,
        animation: google.maps.Animation.DROP,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: "#3b82f6",
          fillOpacity: 1,
          strokeColor: "#ffffff",
          strokeWeight: 3,
        },
      });

      mapRef.current = map;
      setLive(true);
      return true;
    };

    if (tryInit()) return;

    let attempts = 0;
    const interval = setInterval(() => {
      attempts++;
      if (tryInit() || attempts >= 10) clearInterval(interval);
    }, 500);

    return () => clearInterval(interval);
  }, [ready, center]);

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onClick}
      onKeyDown={e => { if (e.key === "Enter" || e.key === " ") onClick(); }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      aria-label="Abrir mapa para iniciar viaje"
      style={{
        width: "100%",
        height: shape === "p-top" ? 192 : 180,
        borderRadius: shape === "p-top" ? "24px 24px 0 0" : 24,
        clipPath: shape === "p-top" ? "polygon(24px 0, calc(100% - 24px) 0, 100% 24px, 100% 180px, 50% 192px, 0 192px, 0 24px)" : undefined,
        cursor: "pointer",
        position: "relative",
        overflow: "hidden",
        boxShadow: hover ? "0 12px 40px rgba(0,0,0,0.2)" : "0 8px 32px rgba(0,0,0,0.15)",
        transform: hover ? "scale(1.01)" : "scale(1)",
        transition: "transform 0.25s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.25s ease",
      }}
    >
      <div ref={containerRef} style={{ width: "100%", height: "100%" }} />
      {!live && (
        <div style={{
          position: "absolute", inset: 0,
          background: "linear-gradient(135deg, #e8edf2 0%, #dde3ea 100%)",
          display: "flex", alignItems: "center", justifyContent: "center",
          zIndex: 1,
        }}>
          <div style={{
            width: 40, height: 40, borderRadius: "50%",
            border: "3px solid rgba(37,99,235,0.15)",
            borderTopColor: "#3b82f6",
            animation: "spin 0.8s linear infinite",
          }} />
          <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
        </div>
      )}
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.12) 100%)",
        pointerEvents: "none",
      }} />
      <div style={{
        position: "absolute", bottom: 14, left: 14, right: 14,
        display: "flex", alignItems: "center", gap: 12,
        background: "rgba(255,255,255,0.95)",
        backdropFilter: "blur(16px) saturate(180%)",
        WebkitBackdropFilter: "blur(16px) saturate(180%)",
        borderRadius: 16,
        padding: "12px 14px",
        boxShadow: "0 4px 20px rgba(0,0,0,0.2)",
      }}>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: "linear-gradient(135deg, #2563eb, #3b82f6)",
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0, boxShadow: "0 4px 8px rgba(37,99,235,0.3)",
        }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
            <circle cx="12" cy="10" r="3" />
          </svg>
        </div>
        <div style={{ textAlign: "left", flex: 1, minWidth: 0 }}>
          <p style={{
            margin: 0, fontSize: 10, fontWeight: 600, letterSpacing: "0.08em",
            color: "rgba(0,0,0,0.4)", fontFamily: "'JetBrains Mono', monospace", textTransform: "uppercase",
          }}>
            TOCÁ PARA COMENZAR
          </p>
          <p style={{
            margin: "2px 0 0", fontSize: 14, fontWeight: 600,
            color: "#121212", fontFamily: "'Inter', sans-serif",
            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          }}>
            {ready && (center.lat !== GUAYAQUIL.lat || center.lng !== GUAYAQUIL.lng)
              ? "Tu ubicación"
              : "Guayaquil, Ecuador"}
          </p>
        </div>
        <div style={{
          width: 28, height: 28, borderRadius: 8,
          background: "rgba(0,0,0,0.04)",
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0,
        }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(0,0,0,0.4)" strokeWidth="2.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>
        </div>
      </div>
    </div>
  );
}
